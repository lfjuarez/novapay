#!/bin/bash
# Caso Novapay · Parte 2 · Comprueba si el servidor quedó contenido y endurecido.
# Uso: sudo bash verificar.sh
if [ "$(id -u)" -ne 0 ]; then echo "Ejecutalo con sudo: sudo bash verificar.sh"; exit 1; fi
ok=0; total=7
chk() { if eval "$2"; then echo "  OK     $1"; ok=$((ok+1)); else echo "  FALTA  $1"; fi; }
echo "Revisión del servidor web-novapay"
chk "El usuario intruso «backups» ya no existe"            "! id backups >/dev/null 2>&1"
chk "La cuenta «soporte» está bloqueada"                     "[ \"\$(passwd -S soporte 2>/dev/null | awk '{print \$2}')\" = L ]"
chk "La clave SSH del atacante ya no está en «soporte»"      "! grep -q 'vps-203-0-113-45' /home/soporte/.ssh/authorized_keys 2>/dev/null && grep -q 'soporte@mesa-de-ayuda' /home/soporte/.ssh/authorized_keys 2>/dev/null"
chk "La tarea programada del atacante ya no está"            "[ ! -e /etc/cron.d/novapay-update ]"
chk "Nada escucha en el puerto 4444"                         "! ss -tln | grep -q ':4444 '"
chk "SSH no acepta contraseñas ni el ingreso como root"      "sshd -T 2>/dev/null | grep -qx 'passwordauthentication no' && sshd -T 2>/dev/null | grep -qx 'permitrootlogin no'"
chk "Solo el dueño puede leer config.env (600)"              "[ \"\$(stat -c %a /opt/novapay/config.env 2>/dev/null)\" = 600 ]"
echo
if [ $ok -eq $total ]; then
  echo "Servidor contenido: $ok de $total controles."
  u="${SUDO_USER:-$(whoami)}"
  echo "Código de verificación: $(printf 'novapay-c6|%s' "$u" | sha256sum | cut -c1-12)"
  echo "Entregalo junto con tu usuario de Cloud Shell: $u"
else
  echo "Faltan $((total-ok)) de $total controles. Revisá los que dicen FALTA."
fi
